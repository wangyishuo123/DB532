I pledge my honor that all parts of this project were done by me alone and
without collaboration with anybody else.
 
CSE532 - Project 3
File name: readme.txt
Author: Yishuo Wang (108533945)
Brief description: show the steps to run the project

1. go to the main page of exist-db(http://localhost:8080/exist), and go to Collections.

2. Click "New Collection" button to reate a new collection called "CSE532" under the "/db". (CSE must be capital)

3. Click "Upload resources" button to upload all the files in the zip file.

4. go to "eXide", go to "/db/CSE532". It has "query1", "query2", "query3", "query4", "query5". You can click it and run the query. 

5. Also, you can go to "allQuery". It will show all 5 query in one page.

6. Check validation: I use the website: http://www.utilities-online.info/xsdvalidation/#.WQGQmIjytaR


